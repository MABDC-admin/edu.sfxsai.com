/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      colors: {
        deped: {
          blue: '#003087',
          gold: '#FFD700',
          light: '#0052CC',
        },
      },
    },
  },
  plugins: [],
};
