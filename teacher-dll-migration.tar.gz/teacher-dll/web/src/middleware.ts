import { NextRequest, NextResponse } from 'next/server';
import { getUserFromReq } from '@/lib/auth';

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Public routes
  if (pathname === '/' || pathname.startsWith('/api/auth') || pathname.startsWith('/_next')) {
    return NextResponse.next();
  }

  const user = await getUserFromReq(req);

  if (!user) {
    return NextResponse.redirect(new URL('/', req.url));
  }

  // Role guards
  if (pathname.startsWith('/teacher') && user.role !== 'teacher') {
    return NextResponse.redirect(new URL('/principal', req.url));
  }
  if (pathname.startsWith('/principal') && user.role !== 'principal') {
    return NextResponse.redirect(new URL('/teacher', req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|public).*)'],
};
