import { NextRequest, NextResponse } from 'next/server';
import { getUserFromReq } from '@/lib/auth';
import { query } from '@/lib/db';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getUserFromReq(req);
  if (!user || user.role !== 'teacher') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { rows } = await query('SELECT * FROM dlls WHERE id=$1 AND teacher_id=$2', [params.id, user.id]);
  const dll = rows[0];
  if (!dll) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  if (!['draft', 'returned'].includes(dll.status)) {
    return NextResponse.json({ error: 'DLL is already submitted or approved' }, { status: 400 });
  }

  const { rows: updated } = await query(
    `UPDATE dlls SET status='submitted', submitted_at=NOW(), updated_at=NOW() WHERE id=$1 RETURNING *`,
    [params.id]
  );
  return NextResponse.json(updated[0]);
}
