import { NextRequest, NextResponse } from 'next/server';
import { getUserFromReq } from '@/lib/auth';
import { query } from '@/lib/db';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getUserFromReq(req);
  if (!user || user.role !== 'principal') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { action, comment } = await req.json(); // action: 'approve' | 'return'
  if (!['approve', 'return'].includes(action)) return NextResponse.json({ error: 'Invalid action' }, { status: 400 });

  const { rows } = await query('SELECT * FROM dlls WHERE id=$1', [params.id]);
  if (!rows[0]) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  if (rows[0].status !== 'submitted') return NextResponse.json({ error: 'DLL must be submitted first' }, { status: 400 });

  const status = action === 'approve' ? 'approved' : 'returned';
  const { rows: updated } = await query(
    `UPDATE dlls SET status=$1, principal_comment=$2, reviewed_at=NOW(), updated_at=NOW() WHERE id=$3 RETURNING *`,
    [status, comment || null, params.id]
  );
  return NextResponse.json(updated[0]);
}
