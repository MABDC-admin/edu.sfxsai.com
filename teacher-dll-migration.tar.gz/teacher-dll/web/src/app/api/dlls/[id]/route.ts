import { NextRequest, NextResponse } from 'next/server';
import { getUserFromReq } from '@/lib/auth';
import { query } from '@/lib/db';

async function getDLL(id: string, userId: number, role: string) {
  const { rows } = await query(
    `SELECT d.*, u.name as teacher_name FROM dlls d JOIN users u ON u.id = d.teacher_id WHERE d.id = $1`,
    [Number(id)]
  );
  const dll = rows[0];
  if (!dll) return null;
  if (role === 'teacher' && dll.teacher_id !== userId) return null;
  return dll;
}

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getUserFromReq(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const dll = await getDLL(params.id, user.id, user.role);
  if (!dll) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  return NextResponse.json(dll);
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getUserFromReq(req);
  if (!user || user.role !== 'teacher') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const dll = await getDLL(params.id, user.id, user.role);
  if (!dll) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  if (dll.status === 'approved') return NextResponse.json({ error: 'Cannot edit an approved DLL' }, { status: 400 });

  const { content, section, grade_level, subject, week_of } = await req.json();
  const { rows } = await query(
    `UPDATE dlls SET content=$1, section=$2, grade_level=$3, subject=$4, week_of=$5, updated_at=NOW()
     WHERE id=$6 RETURNING *`,
    [JSON.stringify(content), section, grade_level, subject, week_of, params.id]
  );
  return NextResponse.json(rows[0]);
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getUserFromReq(req);
  if (!user || user.role !== 'teacher') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const dll = await getDLL(params.id, user.id, user.role);
  if (!dll) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  await query('DELETE FROM dlls WHERE id=$1', [params.id]);
  return NextResponse.json({ ok: true });
}
