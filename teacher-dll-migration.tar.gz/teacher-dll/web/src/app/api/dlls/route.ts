import { NextRequest, NextResponse } from 'next/server';
import { getUserFromReq } from '@/lib/auth';
import { query } from '@/lib/db';
import { emptyDLL } from '@/lib/types';

export async function GET(req: NextRequest) {
  const user = await getUserFromReq(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const quarter = searchParams.get('quarter');
  const grade = searchParams.get('grade');
  const subject = searchParams.get('subject');
  const teacherId = searchParams.get('teacher_id');

  let sql = `
    SELECT d.*, u.name as teacher_name
    FROM dlls d JOIN users u ON u.id = d.teacher_id
    WHERE 1=1
  `;
  const params: unknown[] = [];
  let i = 1;

  if (user.role === 'teacher') {
    sql += ` AND d.teacher_id = $${i++}`; params.push(user.id);
  } else if (teacherId) {
    sql += ` AND d.teacher_id = $${i++}`; params.push(teacherId);
  }
  if (quarter) { sql += ` AND d.quarter = $${i++}`; params.push(Number(quarter)); }
  if (grade)   { sql += ` AND d.grade_level = $${i++}`; params.push(grade); }
  if (subject) { sql += ` AND d.subject = $${i++}`; params.push(subject); }

  sql += ' ORDER BY d.quarter, d.week_number';

  const { rows } = await query(sql, params);
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const user = await getUserFromReq(req);
  if (!user || user.role !== 'teacher') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json();
  const { quarter, week_number, week_of, grade_level, section, subject } = body;
  if (!quarter || !week_number || !week_of || !grade_level || !subject) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  const { rows } = await query(
    `INSERT INTO dlls (teacher_id, quarter, week_number, week_of, grade_level, section, subject, content)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [user.id, quarter, week_number, week_of, grade_level, section || '', subject, JSON.stringify(emptyDLL())]
  );
  return NextResponse.json(rows[0], { status: 201 });
}
