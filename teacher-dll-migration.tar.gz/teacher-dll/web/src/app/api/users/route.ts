import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { getUserFromReq } from '@/lib/auth';
import { query } from '@/lib/db';

export async function GET(req: NextRequest) {
  const user = await getUserFromReq(req);
  if (!user || user.role !== 'principal') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { rows } = await query(
    `SELECT id, name, email, role, grade_level, section, subject, school, created_at
     FROM users ORDER BY role DESC, name`,
    []
  );
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const user = await getUserFromReq(req);
  if (!user || user.role !== 'principal') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { name, email, password, role, grade_level, section, subject, school } = await req.json();
  if (!name || !email || !password || !role) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  const hash = await bcrypt.hash(password, 10);
  try {
    const { rows } = await query(
      `INSERT INTO users (name, email, password_hash, role, grade_level, section, subject, school)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id, name, email, role`,
      [name, email.toLowerCase().trim(), hash, role, grade_level || null, section || null, subject || null, school || 'DepEd School']
    );
    return NextResponse.json(rows[0], { status: 201 });
  } catch {
    return NextResponse.json({ error: 'Email already exists' }, { status: 409 });
  }
}
