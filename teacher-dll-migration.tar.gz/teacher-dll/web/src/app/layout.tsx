import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'M.A Brain Development Center',
  description: 'Daily Lesson Log management system for DepEd teachers',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
