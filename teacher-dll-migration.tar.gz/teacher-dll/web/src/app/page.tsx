'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Login failed'); return; }
      router.push(data.role === 'principal' ? '/principal' : '/teacher');
    } catch {
      setError('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #003087 0%, #0052CC 60%, #1a6fd4 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem' }}>
      {/* Decorative circles */}
      <div style={{ position: 'fixed', top: '-80px', right: '-80px', width: '320px', height: '320px', borderRadius: '50%', background: 'rgba(255,215,0,.08)' }} />
      <div style={{ position: 'fixed', bottom: '-60px', left: '-60px', width: '240px', height: '240px', borderRadius: '50%', background: 'rgba(255,255,255,.05)' }} />

      <div style={{ width: '100%', maxWidth: '420px' }}>
        {/* Logo / Header */}
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <img src="/logo.png" alt="M.A Brain Development Center" style={{ width: '90px', height: '90px', borderRadius: '50%', objectFit: 'cover', margin: '0 auto 1rem', display: 'block', boxShadow: '0 4px 24px rgba(0,0,0,.3), 0 0 0 3px rgba(255,215,0,.4)' }} />
          <h1 style={{ color: '#fff', fontSize: '1.5rem', fontWeight: 800, letterSpacing: '-.01em', lineHeight: 1.2 }}>M.A BRAIN DEVELOPMENT CENTER</h1>
          <p style={{ color: 'rgba(255,215,0,.9)', fontSize: '.85rem', fontWeight: 600, marginTop: '.25rem', letterSpacing: '.04em' }}>Abu Dhabi, UAE</p>
        </div>

        {/* Login card */}
        <div style={{ background: '#fff', borderRadius: '16px', padding: '2rem', boxShadow: '0 20px 60px rgba(0,0,0,.25)' }}>
          <h2 style={{ fontSize: '1.15rem', fontWeight: 700, color: '#003087', marginBottom: '1.5rem' }}>Sign in to your account</h2>

          {error && (
            <div style={{ background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '8px', padding: '.75rem 1rem', color: '#dc2626', fontSize: '.875rem', marginBottom: '1rem' }}>
              {error}
            </div>
          )}

          <form onSubmit={handleLogin}>
            <div style={{ marginBottom: '1rem' }}>
              <label className="dll-label">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="dll-input"
                placeholder="you@deped.edu.ph"
                required
                autoFocus
              />
            </div>
            <div style={{ marginBottom: '1.5rem' }}>
              <label className="dll-label">Password</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="dll-input"
                placeholder="••••••••"
                required
              />
            </div>
            <button type="submit" disabled={loading} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '.75rem', fontSize: '1rem' }}>
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
          </form>

          <div style={{ marginTop: '1.5rem', padding: '1rem', background: '#f8fafc', borderRadius: '8px', fontSize: '.8rem', color: '#64748b' }}>
            <p style={{ fontWeight: 600, marginBottom: '.4rem' }}>Demo accounts (password: <code>deped1234</code>)</p>
            <p>🎓 Principal: <code>principal@deped.edu.ph</code></p>
            <p>📚 Teacher: <code>maria@deped.edu.ph</code></p>
          </div>
        </div>
      </div>
    </div>
  );
}
