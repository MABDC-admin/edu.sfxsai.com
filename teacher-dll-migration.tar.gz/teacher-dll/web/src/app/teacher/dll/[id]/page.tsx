'use client';
import { useState, useEffect, useCallback } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { DLL, DayContent, DLLContent, DAYS, emptyDLL } from '@/lib/types';

const DAY_LABELS: Record<string, string> = {
  monday: 'Monday', tuesday: 'Tuesday', wednesday: 'Wednesday',
  thursday: 'Thursday', friday: 'Friday',
};

export default function DLLEditor() {
  const router = useRouter();
  const { id } = useParams<{ id: string }>();
  const [dll, setDll] = useState<DLL | null>(null);
  const [content, setContent] = useState<DLLContent | null>(null);
  const [activeDay, setActiveDay] = useState<typeof DAYS[number]>('monday');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    const res = await fetch(`/api/dlls/${id}`);
    if (!res.ok) { router.push('/teacher'); return; }
    const data: DLL = await res.json();
    setDll(data);
    const base = emptyDLL(data.week_of);
    // Merge saved content over the empty structure
    const merged: DLLContent = { ...base };
    for (const d of DAYS) {
      merged[d] = { ...base[d], ...(data.content?.[d] || {}) };
    }
    setContent(merged);
  }, [id, router]);

  useEffect(() => { load(); }, [load]);

  const day: DayContent | null = content ? content[activeDay] : null;

  function updateField(field: keyof DayContent, value: string) {
    if (!content) return;
    setContent({ ...content, [activeDay]: { ...content[activeDay], [field]: value } });
    setSaved(false);
  }

  function updateProcedure(field: 'review' | 'motivation' | 'discussion' | 'activity' | 'generalization', value: string) {
    updateField(field, value);
  }

  async function save() {
    if (!dll || !content) return;
    setSaving(true);
    await fetch(`/api/dlls/${id}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content, section: dll.section, grade_level: dll.grade_level, subject: dll.subject, week_of: dll.week_of }),
    });
    setSaving(false); setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  async function submit() {
    setSubmitting(true);
    const res = await fetch(`/api/dlls/${id}/submit`, { method: 'POST' });
    const data = await res.json();
    setSubmitting(false);
    if (res.ok) { setDll(data); alert('DLL submitted for review! ✅'); }
    else alert(data.error);
  }

  if (!dll || !content || !day) return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: '1rem' }}>
      Loading DLL…
    </div>
  );

  const isReadonly = dll.status === 'approved';
  const status = dll.status;
  const statusColors: Record<string, string> = {
    draft: '#64748b', submitted: '#2563eb', approved: '#16a34a', returned: '#ea580c',
  };

  const TA = ({
    label, field, rows = 3, placeholder = '',
  }: {
    label: string;
    field: keyof DayContent;
    rows?: number;
    placeholder?: string;
  }) => (
    <div style={{ marginBottom: '1.1rem' }}>
      <label className="dll-label">{label}</label>
      <textarea
        className="dll-input"
        rows={rows}
        value={day[field] as string}
        disabled={isReadonly}
        placeholder={placeholder}
        onChange={e => updateField(field, e.target.value)}
      />
    </div>
  );

  const weekDates: Record<string, string> = {};
  if (dll.week_of) {
    const base = new Date(dll.week_of + 'T00:00:00');
    DAYS.forEach((d, i) => {
      const dt = new Date(base);
      dt.setDate(dt.getDate() + i);
      weekDates[d] = dt.toISOString().split('T')[0];
    });
  }

  return (
    <div style={{ minHeight: '100vh', background: '#f1f5f9' }}>
      {/* ── Top bar ── */}
      <div style={{
        background: '#003087', color: '#fff', padding: '0 1.5rem',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        height: '60px', boxShadow: '0 2px 12px rgba(0,0,0,.2)',
        position: 'sticky', top: 0, zIndex: 40,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem' }}>
          <button onClick={() => router.push('/teacher')}
            style={{ background: 'rgba(255,255,255,.15)', border: 'none', color: '#fff', borderRadius: '8px', padding: '.35rem .7rem', cursor: 'pointer', fontSize: '1rem' }}>←</button>
          <div>
            <div style={{ fontWeight: 700, fontSize: '.95rem' }}>
              {dll.grade_level} — {dll.subject} | Q{dll.quarter} Week {dll.week_number}
            </div>
            <div style={{ fontSize: '.72rem', opacity: .7 }}>
              {dll.section && `${dll.section} · `}
              {new Date(dll.week_of).toLocaleDateString('en-AE', { month: 'long', day: 'numeric', year: 'numeric' })}
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem' }}>
          <span style={{
            fontSize: '.8rem', fontWeight: 600, padding: '.2rem .7rem', borderRadius: '9999px',
            background: `${statusColors[status]}33`,
            border: `1px solid ${statusColors[status]}66`,
            color: '#fff',
          }}>
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </span>
          {!isReadonly && (
            <button onClick={save} disabled={saving}
              style={{ background: 'rgba(255,255,255,.15)', color: '#fff', border: '1px solid rgba(255,255,255,.3)', borderRadius: '8px', fontSize: '.82rem', padding: '.4rem .9rem', cursor: 'pointer', fontFamily: 'inherit', fontWeight: 600 }}>
              {saving ? 'Saving…' : saved ? '✓ Saved' : 'Save'}
            </button>
          )}
          {['draft', 'returned'].includes(status) && (
            <button onClick={submit} disabled={submitting}
              style={{ background: '#22c55e', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '.82rem', padding: '.4rem .9rem', cursor: 'pointer', fontFamily: 'inherit', fontWeight: 700 }}>
              {submitting ? 'Submitting…' : '📤 Submit'}
            </button>
          )}
        </div>
      </div>

      {/* ── Principal comment ── */}
      {dll.principal_comment && (
        <div style={{
          background: status === 'returned' ? '#fff7ed' : '#f0fdf4',
          borderBottom: `3px solid ${status === 'returned' ? '#fb923c' : '#22c55e'}`,
          padding: '.75rem 1.5rem', fontSize: '.875rem',
        }}>
          <strong>{status === 'returned' ? '⚠️ Returned:' : '✅ Principal:'}</strong> {dll.principal_comment}
        </div>
      )}

      {/* ── DLL Header Card ── */}
      <div style={{ background: '#fff', borderBottom: '1px solid #e2e8f0', padding: '1rem 1.5rem' }}>
        <div style={{ maxWidth: '900px', margin: '0 auto' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem' }}>
            {[
              ['Grade Level', dll.grade_level],
              ['Subject', dll.subject],
              ['Quarter', `Quarter ${dll.quarter}`],
              ['Week', `Week ${dll.week_number}`],
            ].map(([label, val]) => (
              <div key={label} style={{ background: '#f8fafc', borderRadius: '8px', padding: '.6rem .9rem', border: '1px solid #e2e8f0' }}>
                <div style={{ fontSize: '.68rem', color: '#94a3b8', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.05em', marginBottom: '.2rem' }}>{label}</div>
                <div style={{ fontWeight: 700, color: '#1e293b', fontSize: '.9rem' }}>{val}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Day tabs ── */}
      <div style={{ background: '#fff', borderBottom: '1px solid #e2e8f0', padding: '.75rem 1.5rem 0', display: 'flex', gap: '.35rem' }}>
        {DAYS.map(d => (
          <button key={d} className={`day-tab ${activeDay === d ? 'active' : ''}`} onClick={() => setActiveDay(d)}>
            {DAY_LABELS[d]}
          </button>
        ))}
      </div>

      {/* ── DLL form ── */}
      <div style={{ maxWidth: '900px', margin: '0 auto', padding: '1.5rem' }}>

        {/* Header info row */}
        <div className="dll-section">
          <div className="dll-section-header">Daily Information</div>
          <div className="dll-section-body">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div>
                <label className="dll-label">Date</label>
                <input
                  type="date"
                  className="dll-input"
                  value={day.date || weekDates[activeDay] || ''}
                  disabled={isReadonly}
                  onChange={e => updateField('date', e.target.value)}
                />
              </div>
              <div>
                <label className="dll-label">Time</label>
                <input
                  type="text"
                  className="dll-input"
                  value={day.time}
                  disabled={isReadonly}
                  placeholder="e.g. 7:30 AM – 8:30 AM"
                  onChange={e => updateField('time', e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>

        {/* I. Learning Objectives */}
        <div className="dll-section">
          <div className="dll-section-header">I. Learning Objectives</div>
          <div className="dll-section-body">
            <TA label="Learning Objectives" field="learning_objectives" rows={4}
              placeholder="What students will be able to know, do, or feel after the lesson…" />
          </div>
        </div>

        {/* II. Topic / Content */}
        <div className="dll-section">
          <div className="dll-section-header">II. Topic / Content</div>
          <div className="dll-section-body">
            <TA label="Topic / Subject Matter" field="topic_content" rows={3}
              placeholder="Topic title, concept, or unit being covered…" />
          </div>
        </div>

        {/* III. Learning Resources / Materials */}
        <div className="dll-section">
          <div className="dll-section-header">III. Learning Resources / Materials</div>
          <div className="dll-section-body">
            <TA label="Materials, References & Resources" field="learning_resources" rows={4}
              placeholder="Textbooks, worksheets, visual aids, online tools, manipulatives…" />
          </div>
        </div>

        {/* IV. Procedures / Activities */}
        <div className="dll-section">
          <div className="dll-section-header">IV. Procedures / Activities</div>
          <div className="dll-section-body">
            <TA label="A. Review" field="review" rows={3}
              placeholder="Review of previous lesson or prerequisite knowledge…" />
            <TA label="B. Motivation" field="motivation" rows={3}
              placeholder="Activity to arouse interest and engage learners…" />
            <TA label="C. Discussion" field="discussion" rows={4}
              placeholder="Teacher-led discussion, concept development, new lesson presentation…" />
            <TA label="D. Activity" field="activity" rows={4}
              placeholder="Student activities, group work, practice exercises…" />
            <TA label="E. Generalization" field="generalization" rows={3}
              placeholder="Key takeaways, summary, abstract from the lesson…" />
          </div>
        </div>

        {/* V. Assessment / Evaluation */}
        <div className="dll-section">
          <div className="dll-section-header">V. Assessment / Evaluation</div>
          <div className="dll-section-body">
            <TA label="Assessment / Evaluation" field="assessment_evaluation" rows={4}
              placeholder="Quiz, oral recitation, written test, performance task, rubric…" />
          </div>
        </div>

        {/* VI. Assignment / Additional Activity */}
        <div className="dll-section">
          <div className="dll-section-header">VI. Assignment / Additional Activity</div>
          <div className="dll-section-body">
            <TA label="Assignment / Additional Activity" field="assignment" rows={3}
              placeholder="Homework, research, practice or enrichment activity…" />
          </div>
        </div>

        {/* VII. Remarks */}
        <div className="dll-section">
          <div className="dll-section-header">VII. Remarks</div>
          <div className="dll-section-body">
            <TA label="Remarks" field="remarks" rows={3}
              placeholder="Notable observations, class attendance issues, special events…" />
          </div>
        </div>

        {/* VIII. Reflection */}
        <div className="dll-section">
          <div className="dll-section-header">VIII. Reflection</div>
          <div className="dll-section-body">
            <TA label="Reflection" field="reflection" rows={5}
              placeholder="What worked well? What needs improvement? Learner outcomes, difficulties encountered, strategies to try next time…" />
          </div>
        </div>

        {/* Bottom action bar */}
        {!isReadonly ? (
          <div style={{ display: 'flex', gap: '.75rem', justifyContent: 'flex-end', marginTop: '.5rem' }}>
            <button onClick={save} disabled={saving} className="btn btn-primary">
              {saving ? 'Saving…' : saved ? '✓ Saved' : '💾 Save DLL'}
            </button>
            {['draft', 'returned'].includes(status) && (
              <button onClick={submit} disabled={submitting} className="btn btn-success">
                {submitting ? 'Submitting…' : '📤 Submit for Review'}
              </button>
            )}
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '1rem', background: '#f0fdf4', borderRadius: '10px', color: '#16a34a', fontWeight: 600 }}>
            ✅ This DLL has been approved by the principal.
          </div>
        )}
      </div>
    </div>
  );
}
