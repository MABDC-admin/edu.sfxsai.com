export interface User {
  id: number;
  name: string;
  email: string;
  role: 'teacher' | 'principal';
  grade_level?: string;
  section?: string;
  subject?: string;
  school: string;
  created_at: string;
}

// ── New simplified DLL content per day ───────────────────────────────
export interface DayContent {
  date: string;
  time: string;
  learning_objectives: string;
  topic_content: string;
  learning_resources: string;
  // Procedures / Activities
  review: string;
  motivation: string;
  discussion: string;
  activity: string;
  generalization: string;
  // Post-lesson
  assessment_evaluation: string;
  assignment: string;
  remarks: string;
  reflection: string;
}

export interface DLLContent {
  monday: DayContent;
  tuesday: DayContent;
  wednesday: DayContent;
  thursday: DayContent;
  friday: DayContent;
}

export interface DLL {
  id: number;
  teacher_id: number;
  teacher_name?: string;
  quarter: number;
  week_number: number;
  week_of: string;
  grade_level: string;
  section: string;
  subject: string;
  status: 'draft' | 'submitted' | 'approved' | 'returned';
  content: DLLContent;
  principal_comment?: string;
  created_at: string;
  updated_at: string;
  submitted_at?: string;
  reviewed_at?: string;
}

export const GRADE_LEVELS = [
  'Kindergarten 1',
  'Kindergarten 2',
  'Grade 1',
  'Grade 2',
  'Grade 3',
  'Grade 4',
  'Grade 5',
  'Grade 6',
  'Grade 7',
  'Grade 8',
  'Grade 9',
  'Grade 10',
  'Grade 11',
  'Grade 12',
];

// Grade-level subject map per DepEd curriculum
export const GRADE_SUBJECTS: Record<string, string[]> = {
  'Kindergarten 1': [
    'Language, Literacy, and Communication',
    'Mathematics',
    'Science / Sensory and Motor Skills',
    'Makabansa (Social Studies concepts)',
    'Music, Arts, Physical Education (MAPE)',
    'Values Education (integrated in activities)',
  ],
  'Kindergarten 2': [
    'Language, Literacy, and Communication',
    'Mathematics',
    'Science / Sensory and Motor Skills',
    'Makabansa (Social Studies concepts)',
    'Music, Arts, Physical Education (MAPE)',
    'Values Education (integrated in activities)',
  ],
  'Grade 1': [
    'English',
    'Filipino',
    'Mathematics',
    'Science',
    'Araling Panlipunan (AP)',
    'MAPEH (Music, Arts, PE, Health)',
    'Edukasyon sa Pagpapakatao (EsP / Values Education)',
    'Mother Tongue (Grade 1–3)',
  ],
  'Grade 2': [
    'English',
    'Filipino',
    'Mathematics',
    'Science',
    'Araling Panlipunan (AP)',
    'MAPEH (Music, Arts, PE, Health)',
    'Edukasyon sa Pagpapakatao (EsP / Values Education)',
    'Mother Tongue (Grade 1–3)',
  ],
  'Grade 3': [
    'English',
    'Filipino',
    'Mathematics',
    'Science',
    'Araling Panlipunan (AP)',
    'MAPEH (Music, Arts, PE, Health)',
    'Edukasyon sa Pagpapakatao (EsP / Values Education)',
    'Mother Tongue (Grade 1–3)',
  ],
  'Grade 4': [
    'English',
    'Filipino',
    'Mathematics',
    'Science',
    'Araling Panlipunan',
    'MAPEH',
    'Edukasyon sa Pagpapakatao (EsP)',
    'EPP / TLE (Edukasyong Pantahanan at Pangkabuhayan / Technology and Livelihood Education)',
  ],
  'Grade 5': [
    'English',
    'Filipino',
    'Mathematics',
    'Science',
    'Araling Panlipunan',
    'MAPEH',
    'Edukasyon sa Pagpapakatao (EsP)',
    'EPP / TLE (Edukasyong Pantahanan at Pangkabuhayan / Technology and Livelihood Education)',
  ],
  'Grade 6': [
    'English',
    'Filipino',
    'Mathematics',
    'Science',
    'Araling Panlipunan',
    'MAPEH',
    'Edukasyon sa Pagpapakatao (EsP)',
    'EPP / TLE (Edukasyong Pantahanan at Pangkabuhayan / Technology and Livelihood Education)',
  ],
  'Grade 7': [
    'English',
    'Filipino',
    'Mathematics',
    'Science',
    'Araling Panlipunan (Social Studies)',
    'MAPEH (Music, Arts, PE, Health)',
    'Edukasyon sa Pagpapakatao (EsP)',
    'Technology and Livelihood Education (TLE)',
  ],
  'Grade 8': [
    'English',
    'Filipino',
    'Mathematics',
    'Science',
    'Araling Panlipunan (Social Studies)',
    'MAPEH (Music, Arts, PE, Health)',
    'Edukasyon sa Pagpapakatao (EsP)',
    'Technology and Livelihood Education (TLE)',
  ],
  'Grade 9': [
    'English',
    'Filipino',
    'Mathematics',
    'Science',
    'Araling Panlipunan (Social Studies)',
    'MAPEH (Music, Arts, PE, Health)',
    'Edukasyon sa Pagpapakatao (EsP)',
    'Technology and Livelihood Education (TLE)',
  ],
  'Grade 10': [
    'English',
    'Filipino',
    'Mathematics',
    'Science',
    'Araling Panlipunan (Social Studies)',
    'MAPEH (Music, Arts, PE, Health)',
    'Edukasyon sa Pagpapakatao (EsP)',
    'Technology and Livelihood Education (TLE)',
  ],
  'Grade 11': [
    'Oral Communication',
    'Reading and Writing',
    'Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino',
    "Pagbasa at Pagsusuri ng Iba't Ibang Teksto",
    '21st Century Literature',
    'Contemporary Philippine Arts from the Regions',
    'Media and Information Literacy',
    'General Mathematics',
    'Statistics and Probability',
    'Earth and Life Science',
    'Physical Science',
    'Personal Development',
    'Understanding Culture, Society, and Politics',
    'Introduction to Philosophy of the Human Person',
    'Physical Education and Health',
  ],
  'Grade 12': [
    'Oral Communication',
    'Reading and Writing',
    'Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino',
    "Pagbasa at Pagsusuri ng Iba't Ibang Teksto",
    '21st Century Literature',
    'Contemporary Philippine Arts from the Regions',
    'Media and Information Literacy',
    'General Mathematics',
    'Statistics and Probability',
    'Earth and Life Science',
    'Physical Science',
    'Personal Development',
    'Understanding Culture, Society, and Politics',
    'Introduction to Philosophy of the Human Person',
    'Physical Education and Health',
  ],
};

/** Return the subject list for a given grade level */
export const getSubjectsForGrade = (gradeLevel: string): string[] =>
  GRADE_SUBJECTS[gradeLevel] ?? [];

// Flat deduplicated list for principal overview
export const SUBJECTS = Array.from(new Set(Object.values(GRADE_SUBJECTS).flat()));

export const QUARTERS = [1, 2, 3, 4];
export const WEEKS = Array.from({ length: 10 }, (_, i) => i + 1);
export const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'] as const;

export const emptyDay = (date = '', time = ''): DayContent => ({
  date,
  time,
  learning_objectives: '',
  topic_content: '',
  learning_resources: '',
  review: '',
  motivation: '',
  discussion: '',
  activity: '',
  generalization: '',
  assessment_evaluation: '',
  assignment: '',
  remarks: '',
  reflection: '',
});

/** Build an empty DLL content, pre-filling Mon–Fri dates from a Monday ISO string */
export const emptyDLL = (mondayISO = ''): DLLContent => {
  const base = mondayISO ? new Date(mondayISO + 'T00:00:00') : null;
  const dayDate = (offset: number) => {
    if (!base) return '';
    const d = new Date(base);
    d.setDate(d.getDate() + offset);
    return d.toISOString().split('T')[0];
  };
  return {
    monday:    emptyDay(dayDate(0)),
    tuesday:   emptyDay(dayDate(1)),
    wednesday: emptyDay(dayDate(2)),
    thursday:  emptyDay(dayDate(3)),
    friday:    emptyDay(dayDate(4)),
  };
};
