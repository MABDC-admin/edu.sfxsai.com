import { Pool } from 'pg';

const globalPool = global as typeof global & { _pool?: Pool };

if (!globalPool._pool) {
  globalPool._pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 5000,
  });
}

const pool = globalPool._pool;
export default pool;
export const query = (text: string, params?: unknown[]) => pool.query(text, params);
