--
-- PostgreSQL database dump
--

\restrict DHuQG3wZGgEoLVBZTRirZTfMD8b3qsNYjj4GXhPHJeeDevhyAYynHkBLGuxqKCI

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.dlls DROP CONSTRAINT dlls_teacher_id_fkey;
DROP INDEX public.idx_dlls_teacher;
DROP INDEX public.idx_dlls_status;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.dlls DROP CONSTRAINT dlls_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dlls ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.dlls_id_seq;
DROP TABLE public.dlls;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dlls; Type: TABLE; Schema: public; Owner: dll_user
--

CREATE TABLE public.dlls (
    id integer NOT NULL,
    teacher_id integer NOT NULL,
    quarter integer NOT NULL,
    week_number integer NOT NULL,
    week_of date NOT NULL,
    grade_level character varying(20) NOT NULL,
    section character varying(100) DEFAULT ''::character varying NOT NULL,
    subject character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    content jsonb DEFAULT '{}'::jsonb NOT NULL,
    principal_comment text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    submitted_at timestamp with time zone,
    reviewed_at timestamp with time zone,
    CONSTRAINT dlls_quarter_check CHECK (((quarter >= 1) AND (quarter <= 4))),
    CONSTRAINT dlls_status_check CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'submitted'::character varying, 'approved'::character varying, 'returned'::character varying])::text[]))),
    CONSTRAINT dlls_week_number_check CHECK (((week_number >= 1) AND (week_number <= 10)))
);


ALTER TABLE public.dlls OWNER TO dll_user;

--
-- Name: dlls_id_seq; Type: SEQUENCE; Schema: public; Owner: dll_user
--

CREATE SEQUENCE public.dlls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dlls_id_seq OWNER TO dll_user;

--
-- Name: dlls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dll_user
--

ALTER SEQUENCE public.dlls_id_seq OWNED BY public.dlls.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: dll_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    grade_level character varying(20),
    section character varying(100),
    subject character varying(100),
    school character varying(255) DEFAULT 'DepEd School'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['teacher'::character varying, 'principal'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO dll_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: dll_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO dll_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dll_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: dlls id; Type: DEFAULT; Schema: public; Owner: dll_user
--

ALTER TABLE ONLY public.dlls ALTER COLUMN id SET DEFAULT nextval('public.dlls_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: dll_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: dlls; Type: TABLE DATA; Schema: public; Owner: dll_user
--

COPY public.dlls (id, teacher_id, quarter, week_number, week_of, grade_level, section, subject, status, content, principal_comment, created_at, updated_at, submitted_at, reviewed_at) FROM stdin;
2	2	3	1	2026-06-22	Grade 4	A	English	draft	{"friday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}, "monday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}, "tuesday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}, "thursday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}, "wednesday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}}	\N	2026-06-21 18:43:06.046822+00	2026-06-21 18:43:52.980655+00	\N	\N
1	2	1	1	2024-06-03	Grade 4	Rizal	English	returned	{"friday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}, "monday": {"content": "Cause and Effect", "remarks": "", "objectives": {"lc_code": "EN4RC-Ia-2.2.1", "content_standard": "Demonstrates understanding of English language conventions", "learning_competency": "Identify cause and effect relationships", "performance_standard": "Uses English in oral and written communication effectively"}, "procedures": {"reviewing": "Review previous lesson on Main Idea", "discussing_1": "Discuss what causes are and how to identify them", "discussing_2": "Discuss effects and how they relate to causes", "generalizations": "Cause is why something happens; effect is what happens", "developing_mastery": "Students complete a cause-effect graphic organizer", "evaluating_learning": "Answer 5-item cause-effect identification quiz", "presenting_examples": "Show examples of cause-effect sentences", "establishing_purpose": "Present a short story about a storm and its effects", "additional_activities": "Read a short paragraph and identify 2 cause-effect pairs", "practical_applications": "Relate cause and effect to real-life situations"}, "reflection": {"earned_80": "22", "innovation": "Used picture cards to illustrate cause-effect", "difficulties": "Some students struggled with complex sentences", "remedial_worked": "", "need_remediation": "3", "strategies_worked": "Graphic organizer worked well for visual learners", "still_need_remediation": ""}, "learning_resources": {"others": "Manila paper, markers", "lm_pages": "pp. 2-6", "textbook": "", "tg_pages": "pp. 1-5", "lr_portal": ""}}, "tuesday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}, "thursday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}, "wednesday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}}	\N	2026-06-21 18:40:07.413479+00	2026-06-21 18:45:18.082105+00	\N	2026-06-21 18:45:18.082105+00
4	4	1	10	2026-06-15	Kindergarten 1	A	English	draft	{"friday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}, "monday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}, "tuesday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}, "thursday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}, "wednesday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}}	\N	2026-06-21 19:24:31.461872+00	2026-06-21 19:24:31.461872+00	\N	\N
3	2	1	1	2026-06-15	Grade 1	A	Mother Tongue	approved	{"friday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}, "monday": {"content": "afaafdfaf", "remarks": "", "objectives": {"lc_code": "", "content_standard": "a", "learning_competency": "a", "performance_standard": "fffd"}, "procedures": {"reviewing": "f", "discussing_1": "f", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "f", "establishing_purpose": "a", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "a", "difficulties": "", "remedial_worked": "d", "need_remediation": "", "strategies_worked": "d", "still_need_remediation": ""}, "learning_resources": {"others": "fafd", "lm_pages": "fafdfasf", "textbook": "afdsafd", "tg_pages": "dfafdasfasdf", "lr_portal": "dfdsa"}}, "tuesday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}, "thursday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}, "wednesday": {"content": "", "remarks": "", "objectives": {"lc_code": "", "content_standard": "", "learning_competency": "", "performance_standard": ""}, "procedures": {"reviewing": "", "discussing_1": "", "discussing_2": "", "generalizations": "", "developing_mastery": "", "evaluating_learning": "", "presenting_examples": "", "establishing_purpose": "", "additional_activities": "", "practical_applications": ""}, "reflection": {"earned_80": "", "innovation": "", "difficulties": "", "remedial_worked": "", "need_remediation": "", "strategies_worked": "", "still_need_remediation": ""}, "learning_resources": {"others": "", "lm_pages": "", "textbook": "", "tg_pages": "", "lr_portal": ""}}}	ffhdlfads;fasdfhsbf	2026-06-21 18:59:50.970137+00	2026-06-21 19:01:12.360808+00	2026-06-21 19:00:13.998955+00	2026-06-21 19:01:12.360808+00
5	4	2	1	2026-06-15	Kindergarten 1		Language, Literacy, and Communication	draft	{"friday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}, "monday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}, "tuesday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}, "thursday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}, "wednesday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}}	\N	2026-06-21 19:44:46.756799+00	2026-06-21 19:44:46.756799+00	\N	\N
6	4	1	1	2026-06-22	Kindergarten 1	a	Language, Literacy, and Communication	draft	{"friday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}, "monday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}, "tuesday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}, "thursday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}, "wednesday": {"date": "", "time": "", "review": "", "remarks": "", "activity": "", "assignment": "", "discussion": "", "motivation": "", "reflection": "", "topic_content": "", "generalization": "", "learning_resources": "", "learning_objectives": "", "assessment_evaluation": ""}}	\N	2026-06-22 05:11:21.618205+00	2026-06-22 05:11:21.618205+00	\N	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: dll_user
--

COPY public.users (id, name, email, password_hash, role, grade_level, section, subject, school, created_at) FROM stdin;
1	Principal Reyes	principal@deped.edu.ph	$2b$10$Slo6X58uzZNx2nhSRW4w4ecZCivVUMEgT2UDW1eeeqs0fA7HUGgT2	principal	\N	\N	\N	M.A Brain Development Center	2026-06-21 18:40:07.410319+00
2	Teacher Maria Santos	maria@deped.edu.ph	$2b$10$Slo6X58uzZNx2nhSRW4w4ecZCivVUMEgT2UDW1eeeqs0fA7HUGgT2	teacher	\N	\N	\N	M.A Brain Development Center	2026-06-21 18:40:07.410319+00
3	Teacher Juan dela Cruz	juan@deped.edu.ph	$2b$10$Slo6X58uzZNx2nhSRW4w4ecZCivVUMEgT2UDW1eeeqs0fA7HUGgT2	teacher	\N	\N	\N	M.A Brain Development Center	2026-06-21 18:40:07.410319+00
4	KG1 Teacher	kg1@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Kindergarten 1	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
5	KG2 Teacher	kg2@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Kindergarten 2	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
6	Grade 1 Teacher	grade1@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Grade 1	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
7	Grade 2 Teacher	grade2@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Grade 2	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
8	Grade 3 Teacher	grade3@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Grade 3	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
9	Grade 4 Teacher	grade4@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Grade 4	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
10	Grade 5 Teacher	grade5@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Grade 5	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
11	Grade 6 Teacher	grade6@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Grade 6	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
12	Grade 7 Teacher	grade7@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Grade 7	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
13	Grade 8 Teacher	grade8@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Grade 8	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
14	Grade 9 Teacher	grade9@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Grade 9	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
15	Grade 10 Teacher	grade10@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Grade 10	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
16	Grade 11 Teacher	grade11@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Grade 11	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
17	Grade 12 Teacher	grade12@mabdc.org	$2b$10$ERtF4RruIxRufkMv8zoLMe/bLOekqcyo8rnoHuZzJ.IVrCt80dUje	teacher	Grade 12	\N	\N	M.A Brain Development Center	2026-06-21 19:17:33.873632+00
\.


--
-- Name: dlls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dll_user
--

SELECT pg_catalog.setval('public.dlls_id_seq', 6, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dll_user
--

SELECT pg_catalog.setval('public.users_id_seq', 17, true);


--
-- Name: dlls dlls_pkey; Type: CONSTRAINT; Schema: public; Owner: dll_user
--

ALTER TABLE ONLY public.dlls
    ADD CONSTRAINT dlls_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: dll_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: dll_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_dlls_status; Type: INDEX; Schema: public; Owner: dll_user
--

CREATE INDEX idx_dlls_status ON public.dlls USING btree (status);


--
-- Name: idx_dlls_teacher; Type: INDEX; Schema: public; Owner: dll_user
--

CREATE INDEX idx_dlls_teacher ON public.dlls USING btree (teacher_id);


--
-- Name: dlls dlls_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dll_user
--

ALTER TABLE ONLY public.dlls
    ADD CONSTRAINT dlls_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict DHuQG3wZGgEoLVBZTRirZTfMD8b3qsNYjj4GXhPHJeeDevhyAYynHkBLGuxqKCI

