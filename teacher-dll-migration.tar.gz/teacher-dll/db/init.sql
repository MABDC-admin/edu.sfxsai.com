-- ============================================================
-- Teacher DLL System - Database Schema
-- ============================================================

CREATE TABLE IF NOT EXISTS users (
  id          SERIAL PRIMARY KEY,
  name        VARCHAR(255) NOT NULL,
  email       VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role        VARCHAR(20) NOT NULL CHECK (role IN ('teacher', 'principal')),
  grade_level VARCHAR(20),
  section     VARCHAR(100),
  subject     VARCHAR(100),
  school      VARCHAR(255) DEFAULT 'DepEd School',
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS dlls (
  id               SERIAL PRIMARY KEY,
  teacher_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  quarter          INTEGER NOT NULL CHECK (quarter BETWEEN 1 AND 4),
  week_number      INTEGER NOT NULL CHECK (week_number BETWEEN 1 AND 10),
  week_of          DATE NOT NULL,
  grade_level      VARCHAR(20) NOT NULL,
  section          VARCHAR(100) NOT NULL DEFAULT '',
  subject          VARCHAR(100) NOT NULL,
  status           VARCHAR(20) NOT NULL DEFAULT 'draft'
                   CHECK (status IN ('draft','submitted','approved','returned')),
  content          JSONB NOT NULL DEFAULT '{}',
  principal_comment TEXT,
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW(),
  submitted_at     TIMESTAMPTZ,
  reviewed_at      TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_dlls_teacher ON dlls(teacher_id);
CREATE INDEX IF NOT EXISTS idx_dlls_status  ON dlls(status);

-- Seed: password = deped1234
INSERT INTO users (name, email, password_hash, role, school) VALUES
  ('Principal Reyes',
   'principal@deped.edu.ph',
   '$2b$10$Slo6X58uzZNx2nhSRW4w4ecZCivVUMEgT2UDW1eeeqs0fA7HUGgT2',
   'principal',
   'Maasin Central Elementary School'),
  ('Teacher Maria Santos',
   'maria@deped.edu.ph',
   '$2b$10$Slo6X58uzZNx2nhSRW4w4ecZCivVUMEgT2UDW1eeeqs0fA7HUGgT2',
   'teacher',
   'Maasin Central Elementary School'),
  ('Teacher Juan dela Cruz',
   'juan@deped.edu.ph',
   '$2b$10$Slo6X58uzZNx2nhSRW4w4ecZCivVUMEgT2UDW1eeeqs0fA7HUGgT2',
   'teacher',
   'Maasin Central Elementary School')
ON CONFLICT (email) DO NOTHING;

-- Sample DLL
INSERT INTO dlls (teacher_id, quarter, week_number, week_of, grade_level, section, subject, status, content)
VALUES (
  2, 1, 1, '2024-06-03', 'Grade 4', 'Rizal', 'English',
  'submitted',
  '{
    "monday":    {"objectives":{"content_standard":"Demonstrates understanding of English language conventions","performance_standard":"Uses English in oral and written communication effectively","learning_competency":"Identify cause and effect relationships","lc_code":"EN4RC-Ia-2.2.1"},"content":"Cause and Effect","learning_resources":{"tg_pages":"pp. 1-5","lm_pages":"pp. 2-6","textbook":"","lr_portal":"","others":"Manila paper, markers"},"procedures":{"reviewing":"Review previous lesson on Main Idea","establishing_purpose":"Present a short story about a storm and its effects","presenting_examples":"Show examples of cause-effect sentences","discussing_1":"Discuss what causes are and how to identify them","discussing_2":"Discuss effects and how they relate to causes","developing_mastery":"Students complete a cause-effect graphic organizer","practical_applications":"Relate cause and effect to real-life situations","generalizations":"Cause is why something happens; effect is what happens","evaluating_learning":"Answer 5-item cause-effect identification quiz","additional_activities":"Read a short paragraph and identify 2 cause-effect pairs"},"remarks":"","reflection":{"earned_80":"22","need_remediation":"3","remedial_worked":"","still_need_remediation":"","strategies_worked":"Graphic organizer worked well for visual learners","difficulties":"Some students struggled with complex sentences","innovation":"Used picture cards to illustrate cause-effect"}},
    "tuesday":   {"objectives":{"content_standard":"","performance_standard":"","learning_competency":"","lc_code":""},"content":"","learning_resources":{"tg_pages":"","lm_pages":"","textbook":"","lr_portal":"","others":""},"procedures":{"reviewing":"","establishing_purpose":"","presenting_examples":"","discussing_1":"","discussing_2":"","developing_mastery":"","practical_applications":"","generalizations":"","evaluating_learning":"","additional_activities":""},"remarks":"","reflection":{"earned_80":"","need_remediation":"","remedial_worked":"","still_need_remediation":"","strategies_worked":"","difficulties":"","innovation":""}},
    "wednesday": {"objectives":{"content_standard":"","performance_standard":"","learning_competency":"","lc_code":""},"content":"","learning_resources":{"tg_pages":"","lm_pages":"","textbook":"","lr_portal":"","others":""},"procedures":{"reviewing":"","establishing_purpose":"","presenting_examples":"","discussing_1":"","discussing_2":"","developing_mastery":"","practical_applications":"","generalizations":"","evaluating_learning":"","additional_activities":""},"remarks":"","reflection":{"earned_80":"","need_remediation":"","remedial_worked":"","still_need_remediation":"","strategies_worked":"","difficulties":"","innovation":""}},
    "thursday":  {"objectives":{"content_standard":"","performance_standard":"","learning_competency":"","lc_code":""},"content":"","learning_resources":{"tg_pages":"","lm_pages":"","textbook":"","lr_portal":"","others":""},"procedures":{"reviewing":"","establishing_purpose":"","presenting_examples":"","discussing_1":"","discussing_2":"","developing_mastery":"","practical_applications":"","generalizations":"","evaluating_learning":"","additional_activities":""},"remarks":"","reflection":{"earned_80":"","need_remediation":"","remedial_worked":"","still_need_remediation":"","strategies_worked":"","difficulties":"","innovation":""}},
    "friday":    {"objectives":{"content_standard":"","performance_standard":"","learning_competency":"","lc_code":""},"content":"","learning_resources":{"tg_pages":"","lm_pages":"","textbook":"","lr_portal":"","others":""},"procedures":{"reviewing":"","establishing_purpose":"","presenting_examples":"","discussing_1":"","discussing_2":"","developing_mastery":"","practical_applications":"","generalizations":"","evaluating_learning":"","additional_activities":""},"remarks":"","reflection":{"earned_80":"","need_remediation":"","remedial_worked":"","still_need_remediation":"","strategies_worked":"","difficulties":"","innovation":""}}
  }'
) ON CONFLICT DO NOTHING;
